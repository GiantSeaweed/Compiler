#!/bin/bash
make clean
make parser
make test
